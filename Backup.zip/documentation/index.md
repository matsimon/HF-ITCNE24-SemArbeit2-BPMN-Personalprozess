---
layout: default
title: 1. Startseite
nav_order: 1
permalink: /
---

# Willkommen!

Hier findest du die Dokumentation der 2. Semesterarbeit über BPMN von Miguel Schneider.

Diese Webseite wird von Github Pages gehostet.
Sie wird durch meine Einträge im Gitrepo stetig aktualisiert und erneuert.

Ich wünsche dir viel Spass beim Lesen!